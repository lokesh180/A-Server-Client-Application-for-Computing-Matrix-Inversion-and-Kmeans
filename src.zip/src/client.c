// client side C/C++ program to demonstrate Socket
// programming
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netdb.h>
#define PORT 9999
#define SIZE 1024

void error(const char *msg)
{
    perror(msg);
    exit(1);


}

void receive_file(int sockfd){
  int n;
  //int size = 1024;
  FILE *fp;
  char *filename = "recv.txt";
  char buffer[SIZE];
  printf("file receiving...");
  fp = fopen(filename, "w");
  if(fp == NULL)
  {
    error("Error on writing file !");
    exit(1);
  }
  while (1) {
    n = recv(sockfd, buffer, SIZE, 0);
    if (n <= 0){
      printf("breaked..with %d",n);
      break;
      return;
    }
    fprintf(fp, "%s", buffer);
    bzero(buffer, SIZE);
    }
  printf("file written..");
  return;
}

int main(int argc, char* argv[])
{


    int sockfd;
    int portno;
    int n;
    char buffer[255];
    char ch;
    char* ipaddr;
    char filename[50];
    

    struct sockaddr_in serv_addr;
    struct hostent *server;


    if(argc<3)
    {
        fprintf(stderr,"usage %s IPAddress PortNumber \n",argv[0]);
        exit(1);
    }
    
    while((ch=getopt(argc, argv, "p:i:"))!=EOF)
    {
    	switch(ch)
    	{
    		case 'p':
    			portno=atoi(argv[4]);
    			printf("Port registered:%d \n",portno);
    			break;
    		case 'i':
    			ipaddr=argv[2];
    			printf("IP registered:%s \n",ipaddr);
    			break;
    		default:
    			fprintf(stderr, "Unknown Flag given : %s\n", optarg);
    			return 1;
    	}
    }
    
    sockfd=socket(AF_INET,SOCK_STREAM,0);
    if(sockfd<0)
    {
        error("Error opening Socket!");

    }
    printf("Socket Created\n");
    //ipaddr=;
    //if(ipaddr==NULL)
    /*{
        fprintf(stderr,"Invalid Host!");

    }*/

    //bzero((char *) & serv_addr,sizeof(serv_addr));
    serv_addr.sin_family=AF_INET;
    //bcopy((char *)server->h_addr,(char *) & serv_addr.sin_addr.s_addr,server->h_length);
    serv_addr.sin_port=htons(portno);
    serv_addr.sin_addr.s_addr=inet_addr(ipaddr);

    if(connect(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
    {
        error("Connection failed");
    }


    printf("Connected to the server! \n");
    printf(" .... \n");
    
    while(1)
    {
        printf("Enter a command for the server : ");
        bzero(buffer,255);
        char pathfilename[255]="../../computed_results/";
        fgets(buffer,255,stdin);
        n= write(sockfd,buffer,strlen(buffer));

        if(n<0)
        {
            error("Error on writing!\n");

        }
        bzero(buffer,255);
        /*n=read(sockfd,buffer,255);

        if(n<0)
        {
            error("error on reading");
        }

        printf("Received the solution : %s",buffer);*/
        /*char send[] ="sending ACK";
        n= write(sockfd,send,strlen(send));
        //filename=(char*)malloc(sizeof(buffer)+1);
        //printf("filname initalized..");
        //pathfilename="../../computed_results";
        strncpy(filename,buffer,sizeof(buffer));
        printf("buffer copied..");
        //printf("Filename with path:%s",pathfilename);
        strcat(pathfilename,filename);
        printf("Filename with path:%s",pathfilename);*/
        //sprintf(pathfilename, "./filecreation.sh matinv_client%d_soln",i);
        FILE *fp;
        read(sockfd,buffer,255);
        fp=fopen("add1.txt","w");
        fprintf(fp,"%s",buffer);
        printf("the file was received successfully");
        printf("the new file created is add1.txt");
        
        //receive_file(sockfd);
        //free(filename);
        //int i= strncmp("Bye",buffer,3);
        /*if(i==0)
        {
            break;
        }*/
        //memset(filename,0,255);




    }

    close(sockfd);


    return 0;
}
