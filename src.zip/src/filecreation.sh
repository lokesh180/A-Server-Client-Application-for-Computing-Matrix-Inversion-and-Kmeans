#!/bin/bash
name=$1
if [[ -e $name.txt || -L $name.txt ]] ; then
    i=1
    while [[ -e $name-$i.txt || -L $name-$i.txt ]] ; do
        let i++
    done
    name=$name-$i
fi
#touch -- "$name".txt
echo $name.txt > filename.txt

