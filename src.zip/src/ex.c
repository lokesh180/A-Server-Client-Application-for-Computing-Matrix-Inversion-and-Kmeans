#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <ctype.h>
void main()
{
    FILE* file;
char filename[1][50];
file=fopen("filename.txt","r");
int line = 0;
while(!feof(file) && !ferror(file)){
if(fgets(filename[line],50,file)!=NULL){
    break;
    }
}
fclose(file);
char* ch= (char*)filename;


    while(isspace((unsigned char)ch[0]))
        ch++;
    char *final = strdup(ch);
    int length = strlen(final);
    while(length > 0 && isspace((unsigned char)final[length-1]))
        length--;
    final[length] = '\0';
  



printf("Filename %s",final);
FILE *fp=fopen(final,"r");
if(fp == NULL)
{
    printf("Error on reading file !");
    exit(1);
}
printf("file opened..");
fclose(fp);
}
