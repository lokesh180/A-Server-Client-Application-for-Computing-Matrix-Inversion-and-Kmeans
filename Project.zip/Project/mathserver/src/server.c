// Server side programming
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <ctype.h>
#define PORT 9999
#define SIZE 100

void error(const char *msg)
{
    perror(msg);
    exit(1);


}

/*void send_file(FILE *fp, int sockfd){
    int n;
    char data[SIZE] = {0};

    while(fgets(data, SIZE, fp) != NULL) {
    if (send(sockfd, data, sizeof(data), 0) == -1) {
        perror("[-]Error in sending file.");
        exit(1);
    }
    bzero(data, SIZE);
    }
}*/

int send_file(int sockfd){
    char fname[256] = "matinv_client1_soln.txt";
    printf("Connection accepted and id: %d\n",sockfd);
      //printf("Connected to Clent: %s:%d\n",inet_ntoa(c_addr.sin_addr),ntohs(c_addr.sin_port));
       write(sockfd, fname,256);

        FILE *fp = fopen(fname,"rb");
        if(fp==NULL)
        {
            printf("File opern error");
            return 1;   
        }   

        /* Read data from file and send it */
        while(1)
        {
            /* First read file in chunks of 256 bytes */
            unsigned char buff[1024]={0};
            int nread = fread(buff,1,1024,fp);
            printf("Bytes read %d \n", nread);

            /* If read was success, send data. */
            if(nread > 0)
            {
                printf("Sending \n");
                write(sockfd, buff, nread);
            }
            if (nread < 1024)
            {
                if (feof(fp))
		        {
                    printf("End of file\n");
		            printf("File transfer completed for id: %d\n",sockfd);
		        }
                if (ferror(fp))
                    printf("Error reading\n");
                break;
            }
        }
}

char* filename()
{
    FILE* file;
    char filename[100][1000];
    file=fopen("serverfiles/filename.txt","r");
    int line = 0;
    while(!feof(file) && !ferror(file)){
    if(fgets(filename[line],1000,file)!=NULL){
        line++;
        }
    }
    fclose(file);
    char* ch= (char*)filename;
    return ch;
}

char *removeWS( char *string)
{
    while(isspace((unsigned char)string[0]))
        string++;
    char *final = strdup(string);
    int length = strlen(final);
    while(length > 0 && isspace((unsigned char)final[length-1]))
        length--;
    final[length] = '\0';
    return final;
}

int main(int argc, char* argv[])
{

    if(argc <3)
    {
        fprintf(stderr,"Port number should be provided with -p flag\n");
        exit(1);
    }

    int sockfd;
    int newsockfd;
    int portno;
    int n;
    char buffer[SIZE];
    char *cmd=NULL;
    //char cmd1[255]=NULL;
    //char send[255];
    char ch,data[SIZE];
    int i=0;
    pid_t pid;
    int result;
    int childpid=0;
    char file[500];
    //FILE* fp;
    //char fname[50];
    //char foo[4096];
    #define die(e) do { fprintf(stderr, "%s\n", e); exit(EXIT_FAILURE); } while(0);
    

    struct sockaddr_in serv_addr;
    struct sockaddr_in cli_addr;
    socklen_t clilen;
    
    while((ch=getopt(argc, argv, "p:"))!=EOF)
    {
    	switch(ch)
    	{
    		case 'p':
    			portno=atoi(argv[2]);
    			break;
    		default:
    			fprintf(stderr, "Unknown Flag given : %s\n", optarg);
    			return 1;
    	}
    }

    sockfd = socket(AF_INET,SOCK_STREAM,0);



    printf("****Welcome to Math Server!****\n");
    //printf("Server connected to port %s!\n",argv[2]);




    if(sockfd<0)
    {

        error("ERROR opening Socket!");
    }


    //bzero((char *)&serv_addr,sizeof(serv_addr)); /// clears the address

    

     /*if (setsockopt(sockfd, SOL_SOCKET,
                   SO_REUSEADDR | SO_REUSEPORT, &n,
                   sizeof(n))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }*/

    serv_addr.sin_family=AF_INET;
    serv_addr.sin_addr.s_addr=INADDR_ANY;
    serv_addr.sin_port=htons(portno);

    if(bind(sockfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr))<0)
    {
        error("Binding Failed\n");
    }

    //printf("Binding is done to the port!\n");

    listen(sockfd,5);/// maximum client connection limit sets to 5
    printf("Listening for Clients...\n");
    

    while(1)
    {
    	clilen=sizeof(cli_addr);
	    newsockfd = accept(sockfd,(struct sockaddr*) & cli_addr,&clilen);
    	if(newsockfd<0)
    	{

        	error("Error on Accept");
    	}
	    i=i+1;
    	printf("\nServer connected to Client : %d!\n",i);
    	
    	
    	if((childpid=fork()) == 0)
    	{
    		close(sockfd);
    		while(1)
    		{
    			bzero(buffer,SIZE);

                //bzero(data,255);
        		n=read(newsockfd,buffer,SIZE);
        		if(n<0)
        		{
            			error("Error on reading data!");
        		}
                int ext= strncmp("exit",buffer,3);
                int nothing=strcmp("",buffer);
                if(ext==0 || nothing==0)
                {
                    printf("Client %d Exit",i);
                    exit(0);
                }
        		//printf("\nClient request : %s\n",buffer);
                printf("Client %d Commanded : %s",i,buffer);
                cmd=(char*)malloc(sizeof(buffer)+1);
                char cmd1[SIZE]="./";
        		/*memmove(data,buffer,sizeof(buffer));
                printf("The last values :%d and %d",data[254],data[255]);
        		memmove(data+2,data,253);
        		data[0]='.';
        		data[1]='/';
                printf("The last values :%d and %d",data[254],data[255]);
                memmove(cmd,data,sizeof(data));*/
                
                //printf("The last values :%d and %d",data[254],data[255]);
        		//memmove(buffer+2,buffer,253);
        	    //buffer[0]='.';
        		//buffer[1]='/';
                //printf("The last values :%d and %d",buffer[254],buffer[255]);
                strncpy(cmd,buffer,sizeof(buffer));
                //memset(data,0,255);
                cmd=removeWS(cmd);
                int matpar =strncmp(cmd,"matinvpar",9);
                int matinv = strncmp(cmd,"matinv",6);
                int kmeanspar = strncmp(cmd,"kmeanspar",9);
                int kmeans = strncmp(cmd,"kmeans",6);
                if( matpar==0 ||matinv==0 ){
                    sprintf(file, "cd serverfiles/ ; ./filecreation.sh matinv_client%d_soln",i);
                }
                else if(kmeanspar==0 || kmeans==0){
                    sprintf(file, "cd serverfiles/ ; ./filecreation.sh kmeans_client%d_soln",i);
                }
                else{
                    printf("\nThe Server accepts only kmeans and matinv commands, Provide Correct Command");
                    continue;
                }
                
                result = system(file);
                if(result!=0){
                    printf("\nInvalid Command to Server %s",buffer);
                    continue;
                }
                
                char *fname =filename();
                //printf("\nfile name: %s\n",fname);



                //printf("%s\n",filename);
                strcat(cmd1,cmd);
                //strcat(cmd1," > matinv_client1_soln.txt");
                strcat(cmd1," > ");
                strcat(cmd1," serverfiles/");
                strcat(cmd1,fname);
                //printf("%s\n",cmd);
        		//printf("\nClient %d Commanded : %s\n",i,cmd1);
        		result = system(cmd1);
        		
        		if(result!=0){
                    printf("\nInvalid Command to Server %s",buffer);
                }
        		memset(cmd1,0,SIZE);
        		free(cmd);
        		
        		//printf("you : ");

        		bzero(buffer,SIZE); /// clears the buffer
        		//fgets(buffer,255,"Execution Successful!!!");
        		//sprintf(buffer,"Received the solution : %d ",(long) my_double_variable);
			    //char send[] ="Received the solution : matinv_client_solution.txt";
                //memcpy(buffer,send,sizeof(send));
        		//n= write(newsockfd,buffer,strlen(buffer));
                printf("Sending solution : %s",fname);
                n= write(newsockfd,fname,strlen(fname));
                //printf("Filename sent");
                /*bzero(buffer,255);
                n=read(newsockfd,buffer,255);
                printf("Client sends msg:%s",buffer);*/
                //fname=removeWS(fname);
                //printf("Filename %s",fname);
                //char *name= "kmeans-data.txt";
                //FILE *fp=fopen(name, "r");
                //if(fp == NULL)
        		//{
            	//		error("Error on reading file !");
                //        exit(1);
        		//}
                //send_file(newsockfd);
                //printf("[+]File data sent successfully.\n");
                /*FILE *f;
                f=fopen("add.txt","r");
                fscanf(fp,"%s",buffer);
                write(newsockfd,buffer,255);
                printf("the file was sent successfully");*/
                
                
                //sleep(10);
                //break;
                

        		/*if(n<0)
        		{
            			error("Error on writing!");
        		}*/
                //cmd.free();
        	}
            
        }
   }

    return 0;
}
