Steps for Execution:-
1. Open two Terminals and run makefile in one terminal 
2. Then execute server with command "./server -p 9999".
3. Client with "/client -ip 127.0.0.1 -p 9999"
4. Sever expects commands from client and server is able to compute two programs "Inverse Matrix and Kmeans". If other provided shows a print statement of user defined error.
5. The client commands should be in format
   for Matrix Inverse Parallel program -> matinvpar -n 8 -I fast -P 1(statically intialized to 1 for saved the results to file).
   for Kmeans parallel program -> kmeanspar -f kmeans-data.txt -k 8.
6. If the client exits by SIGINT(CTRL+C) the server recogines and shows message that client exited.
7. The server handlees multiple clients by using fork strategy.
8. The resulted files will be saved a new files with number after the name (doesn't overide same file) as per asignment descriptor.
9. A screenshot is attached, which shows the execution with three clients
10. The server creates files and stores in serverfiles folder.
11. Finally results files with same names are created by client in computed results folder.
