// client side C/C++ program to demonstrate Socket
// programming
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>

#define PORT 9999
#define SIZE 1024

void error(const char *msg)
{
    perror(msg);
    exit(1);


}

void gotoxy(int x,int y)
 {
 printf("%c[%d;%df",0x1B,y,x);
 }

void receive_file(int sockfd){
    int n;
    FILE *fp;
    char *filename = "recv.txt";
    char buffer[SIZE];

    fp = fopen(filename, "w");
    while (1) {
        n = recv(sockfd, buffer, SIZE, 0);
        if (n <= 0){
        break;
        return;
    }
    fprintf(fp, "%s", buffer);
    bzero(buffer, SIZE);
    }
    return;
}

int main(int argc, char* argv[])
{


    int sockfd;
    int portno;
    int n;
    char buffer[SIZE];
    char ch;
    char* ipaddr;
    char filename[SIZE];
    
    

    struct sockaddr_in serv_addr;
    struct hostent *server;


    if(argc<3)
    {
        fprintf(stderr,"usage %s IPAddress PortNumber \n",argv[0]);
        exit(1);
    }
    
    while((ch=getopt(argc, argv, "p:i:"))!=EOF)
    {
    	switch(ch)
    	{
    		case 'p':
    			portno=atoi(argv[4]);
    			printf("Port registered:%d \n",portno);
    			break;
    		case 'i':
    			ipaddr=argv[2];
    			printf("IP registered:%s \n",ipaddr);
    			break;
    		default:
    			fprintf(stderr, "Unknown Flag given : %s\n", optarg);
    			return 1;
    	}
    }
    
    sockfd=socket(AF_INET,SOCK_STREAM,0);
    if(sockfd<0)
    {
        error("Error opening Socket!");

    }
    printf("Socket Created\n");
    //ipaddr=;
    //if(ipaddr==NULL)
    /*{
        fprintf(stderr,"Invalid Host!");

    }*/

    //bzero((char *) & serv_addr,sizeof(serv_addr));
    serv_addr.sin_family=AF_INET;
    //bcopy((char *)server->h_addr,(char *) & serv_addr.sin_addr.s_addr,server->h_length);
    serv_addr.sin_port=htons(portno);
    serv_addr.sin_addr.s_addr=inet_addr(ipaddr);

    if(connect(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
    {
        error("Connection failed");
    }


    printf("Connected to the server! \n");
    printf(" .... \n");
    
    while(1)
    {
        printf("Enter a command for the server : ");
        bzero(buffer,255);
        char pathfilename[SIZE]= "../../computed_results/";
        fgets(buffer,255,stdin);
        
        n= write(sockfd,buffer,strlen(buffer));

        if(n<0)
        {
            error("Error on writing!\n");

        }
        int i= strncmp("exit",buffer,3);
        if(i==0)
        {
            break;
        }
        bzero(buffer,SIZE);
        n=read(sockfd,buffer,255);

        if(n<0)
        {
            error("error on reading");
        }

        printf("Received the solution : %s",buffer);
        //char send[] ="sending ACK";
        //n= write(sockfd,send,strlen(send));
        //filename=(char*)malloc(sizeof(buffer)+1);
        //printf("filname initalized..");
        //pathfilename="../../computed_results";
        strncpy(filename,buffer,sizeof(buffer));
        //printf("buffer copied..");
        //printf("Filename with path:%s",pathfilename);
        strcat(pathfilename,filename);
        printf("\nFilename with path:%s",pathfilename);
        bzero(buffer,SIZE);
        bzero(filename,SIZE);
        //sprintf(pathfilename, "./filecreation.sh matinv_client%d_soln",i);
        /*FILE *fp;
        read(sockfd,buffer,255);
        fp=fopen("add1.txt","w");
        fprintf(fp,"%s",buffer);
        printf("the file was received successfully");
        printf("the new file created is add1.txt");*/
        
        //receive_file(sockfd);
        //printf("[+]Data written in the file successfully.\n");
        //printf("[+]Closing the connection.\n");
        //close(sockfd);
        //free(filename);
        //int i= strncmp("Bye",buffer,3);
        /*if(i==0)
        {
            break;
        }*/
        //memset(filename,0,255);

        /* Create file where data will be stored */
    	/*FILE *fp;
	char fname[256];
	read(sockfd, fname, 256);
	//strcat(fname,"AK");
	printf("File Name: %s\n",fname);
	printf("Receiving file...");
   	 fp = fopen("recv.txt", "wb"); 
    	if(NULL == fp)
    	{
       	 printf("Error opening file");
         return 1;
    	}
    long double sz=1;
    int bytesReceived =0;
    /* Receive data in chunks of 256 bytes */
    /*while((bytesReceived = read(sockfd, buffer, 1024)) > 0)
    { 
        sz++;
        gotoxy(0,4);
        //printf("Received: %llf Mb",(sz/1024));
	//fflush(stdout);
        // recvBuff[n] = 0;
        fwrite(buffer, 1,bytesReceived,fp);
        
    }

    if(bytesReceived < 0)
    {
        printf("\n Read Error \n");
    }
    printf("\nFile OK....Completed\n");*/

    /*n=read(sockfd,buffer,SIZE);
    printf("%s", buffer);
    if(n<0)
    {
        error("Error on reading data!");
    }
    printf("%s", buffer);

    n=read(sockfd,buffer,SIZE);
    if(n<0)
    {
        error("Error on reading data!");
    }*/
    

    }

    close(sockfd);


    return 0;
}
