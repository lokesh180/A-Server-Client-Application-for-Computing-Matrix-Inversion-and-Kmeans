// Server side programming
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#define PORT 9999

void error(const char *msg)
{
    perror(msg);
    exit(1);


}


int main(int argc, char* argv[])
{

    if(argc <3)
    {
        fprintf(stderr,"Port number should be provided with -p flag\n");
        exit(1);
    }

    int sockfd;
    int newsockfd;
    int portno;
    int n;
    char buffer[255];
    char *buf;
    char ch,data;
    int i=1;
    pid_t pid;
    int link[2];
    int childpid=0;
    char foo[4096];
    #define die(e) do { fprintf(stderr, "%s\n", e); exit(EXIT_FAILURE); } while(0);
    

    struct sockaddr_in serv_addr;
    struct sockaddr_in cli_addr;
    socklen_t clilen;
    
    while((ch=getopt(argc, argv, "p:"))!=EOF)
    {
    	switch(ch)
    	{
    		case 'p':
    			portno=atoi(argv[2]);
    			break;
    		default:
    			fprintf(stderr, "Unknown Flag given : %s\n", optarg);
    			return 1;
    	}
    }

    sockfd = socket(AF_INET,SOCK_STREAM,0);



    printf("\nWelcome to Math Server!...\n");
    printf("Server connected to port %s!\n",argv[2]);




    if(sockfd<0)
    {

        error("ERROR opening Socket!");
    }


    //bzero((char *)&serv_addr,sizeof(serv_addr)); /// clears the address

    

     /*if (setsockopt(sockfd, SOL_SOCKET,
                   SO_REUSEADDR | SO_REUSEPORT, &n,
                   sizeof(n))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }*/

    serv_addr.sin_family=AF_INET;
    serv_addr.sin_addr.s_addr=INADDR_ANY;
    serv_addr.sin_port=htons(portno);

    if(bind(sockfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr))<0)
    {
        error("Binding Failed\n");
    }

    printf("Binding is done to the port!\n");

    listen(sockfd,5);/// maximum client connection limit sets to 5
    printf("Listening...\n Waiting for Clients....\n");
    

    while(1)
    {
    	clilen=sizeof(cli_addr);
	newsockfd = accept(sockfd,(struct sockaddr*) & cli_addr,&clilen);
    	if(newsockfd<0)
    	{

        	error("Error on Accept");
    	}
	
    	printf("Server connected to Client : %d!\n",i);
    	i=i+1;
    	
    	if((childpid=fork()) == 0)
    	{
    		close(sockfd);
    		while(1)
    		{
    			bzero(buffer,255);
        		n=read(newsockfd,buffer,255);
        		if(n<0)
        		{
            			error("Error on reading data!");
        		}
        		data=buffer;
        		buf = (char *)data;
        		printf("\nClient request : %s\n",buf);
        		
        		if(pipe(link)==-1)
        			die("pipe");

			if((pid = fork()) == -1)
				die("fork");        		
        		
        		if(pid == 0)
        		{
        			dup2 (link[1], STDOUT_FILENO);
        			close(link[0]);
        			close(link[1]);
        			char *args[] = {buf, "-n","4","-P","1","-I","fast",NULL};
        			execv(buf,args);
        			die("execv");
        		}
        		else
        		{
        			close(link[1]);
        			int nbytes = read(link[0], foo, sizeof(foo));
        			printf("Output: (%.*s)\n", nbytes, foo);
        			wait(NULL);
        		}
        		
        		//printf("you : ");

        		bzero(buffer,255); /// clears the buffer
        		//fgets(buffer,255,stdin);

        		//n= write(newsockfd,buffer,strlen(buffer));

        		//if(n<0)
        		//{
            			//error("Error on writing!");
        		//}
        	}
        }
   }

    return 0;
}
